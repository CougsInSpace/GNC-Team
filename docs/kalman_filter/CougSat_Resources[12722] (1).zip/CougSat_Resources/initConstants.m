%[ports,dyear,maxdef,epoch,c,cd,fn,fm,snorm,k]=aeroicon('aeroblkwmm2010','icon');
load worldMagModelParams
SS.constants.earth.radius=6378137; %[m]
SS.constants.earth.eccentricity=0.081819190842; %[m]
SS.constants.earth.mu=398600.4418; %[km^3/s^2]