% Specify the standard deviation of the gyro rate noise
SS.SC.ADCS.ADS.KF.sig_r = 0.129;

% Specify the standard deviation of the gyro bias
SS.SC.ADCS.ADS.KF.sig_w = 0.1;
%SS.SC.ADCS.ADS.KF.sig_w = .055;

% Specify the sun sensor measurement noise matrix R_ss
SS.SC.ADCS.ADS.KF.R_ss = 0.1*eye(3);

% Specify the magnetometer measurement noise matrix R_m
SS.SC.ADCS.ADS.KF.R_m = 0.05*eye(3);

SS.SC.ADCS.ADS.KF.Pk0=eye(6);
%SS.SC.ADCS.ADS.KF.q0_I2B
SS.SC.ADCS.ADS.KF.bias0=zeros(3,1);