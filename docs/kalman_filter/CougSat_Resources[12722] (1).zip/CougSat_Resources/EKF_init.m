% file EKF_init.m
%
% This m-file provides initialization parameters as well as a call to the
% main function for the EKF developed for the EDSN mission.
%
% Written by: Matt Sorgenfrei                 matthew.c.sorgenfrei@nasa.gov
% Last Updated: 02/26/2013
%-------------------------------------------------------------------------%

% Clear anything from the past run
clear all; close all; clc;

% Specify the number of time steps
n = 10000;

% Load-in a sample set of data provided by Kim
load KFData.mat

% The time step for the simulation is 0.1 seconds
dt = 0.1;

% The initial guess for the quaternion just places a 1 in the scalar
% position
q0_I2B = [0; 0; 0; 1;];

% Specify a 4x1 array of variances. 
%sig = [.01; 0.01; 0.01; 0.01;];

% Specify the standard deviation of the gyro rate noise
sig_r = 0.129;

% Specify the standard deviation of the gyro bias
sig_w = 0.1;

% Specify the sun sensor measurement noise matrix R_ss
R_ss = 0.1*eye(3);

% Specify the magnetometer measurement noise matrix R_m
R_m = 0.05*eye(3);

% Specify whether or not the spacecraft is in eclipse (1 is in eclipse, 0
% is not in eclipse)
eclp = 1;

% Construct the initial covariance matrix
%Pk0 = [(50*pi/180)^2*eye(3) zeros(3);...
%    zeros(3) (0.2/3600*pi/180)^2*eye(3)];

Pk0 = eye(6);

% Read-in data from the stored workspace KFData.mat

%w = w_B2I_B(1:n,:)';
Br = BRef(1:n,:)';
Bm = magnetometerData(1:n,:)';
Sr = SunRef(1:n,:)';
Sm = sunVector(1:n,:)';
%qk = qI2B(1:n,:)';
gyro = gyroData(1:n,:)';

% Intialize arrays for testing
wk = zeros(3,n);
biask = zeros(3,n);
Pk = zeros(6,6,n);
qk = zeros(4,n);

% Currently running two versions of the EKF, the second one will use the _M
% variables
%wk_M = zeros(3,n);
%biask_M = zeros(3,n);
%Pk_M = zeros(6,6,n);
%qk_M = zeros(4,n);

% Write in the initial estimate for the states

qk(:,1) = [qI2B(1,2:4) qI2B(1,1)]';
%qk(:,1) = q0_I2B;
wk(:,1) = w_B2I_B(1,:)';
biask(:,1) = zeros(3,1);

%qk_M(:,1) = [qI2B(1,2:4) qI2B(1,1)]';
%qk_M(:,1) = q0_I2B;
%wk_M(:,1) = w_B2I_B(1,:)';
%biask_M(:,1) = zeros(3,1);

Pk(:,:,1) = Pk0;
%Pk_M(:,:,1) = Pk0;

%break

% Only use the first 100 data point for now just in case something is
% messed up

% for j = 1:n
%
% w(:,j) = w_B2I_B2(j,:);
% Br(:,j) = BRef(j,:);
% Bm(:,j) = magnetometerData(j,:);
% Sr(:,j) = SunRef(j,:);
% Sm(:,j) = sunVector(j,:);
% end

for i = 2:n
    
    % First run the algorithm using Vince's quaternion correction
    %[wk(:,i),qk(:,i),biask(:,i),Pk(:,:,i)] =...
    %    EKF_main2(gyro(:,i-1),qk(:,i-1),biask(:,i-1),Sm(:,i-1),Sr(:,i-1),eclp,Bm(:,i-1),Br(:,i-1),dt,sig,Pk(:,:,i-1));
    
    % Now run it using the correction from [2]
    %[wk_M(:,i),qk_M(:,i),biask_M(:,i),Pk_M(:,:,i)] =...
     %   EKF_main3(gyro(:,i-1),qk_M(:,i-1),biask_M(:,i-1),Sm(:,i-1),Sr(:,i-1),eclp,Bm(:,i-1),Br(:,i-1),dt,sig,Pk_M(:,:,i-1));
		
    [wk(:,i),qk(:,i),biask(:,i),Pk(:,:,i)] =...
    EKF_main4(gyro(:,i-1),qk(:,i-1),biask(:,i-1),Sm(:,i-1),Sr(:,i-1),eclp,Bm(:,i-1),Br(:,i-1),dt,sig_r,sig_w,R_ss,R_m,Pk(:,:,i-1));
    
end


