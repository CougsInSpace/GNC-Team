function [wk1_B2I_B,qk1_I2B,biask1,Pk1] = EKF_main4(wk_B2I_B,qk_I2B,biask,SMeas,SRef,eclp,BMeas,BRef,dt,sig_r,sig_w,R_ss,R_m,Pk)
%function EKF.m
%
% This function provides an estimate of the vector components of the
% quaternion as well as the biases associated with the three axes of gyro
% measurements used for the EDSN spacecraft. This results in a state vector
% x = [Theta; bias;]', where Theta is the vector component of the
% quaternioin and bias is a 3x1 vector of biases. Using these bias values,
% the angular velocity w_B2I_B can also be estimated.
%
% Note: Since gyro biases are being used to propagate the spacecraft state,
% and since the gyro measures the angular velocity of the spacecraft body
% with respect to the inertial frame, all outputs in this routine are
% referenced to the inertial frame
%
% Note: The quaternions that are operated on within the actual EKF routine
% are defined with the scalar in the 4th position, as opposed to the rest
% of the simulation which assumes the scalar is in the 1st position.
%
% Inputs
% wk_B2I_B: The angular velocity of the spacecraft as measured by the 3-axis
%          gyro (3x1 vector)
% qk_I2B: The current quaternion describing the rotation from the body
%         frame to the inertial frame
% SMeas:  The sun vector measured in the body frame
% SRef:   The reference sun vector resolved in the inertial frame
% eclp:   A flag indicating whether or not the spacecraft is in eclipse
% BMeas:  The magnetic field vector measured in the inertial frame
% BRef:   The reference magnetic field vector resolved in the inertial
%         frame
% dt:     The time step used in the simulation
% sig_r:  The standard deviation of the gyro rate noise
% sig_w:  The standard deviation of the gyro bias noise
% R_ss:	  The 3x3 measurement noise matrix associated with the sun sensor
% R_m:	  The 3x3 measurement noise matrix associated with the magnetometer
% Pk:     The initial covariance matrix
%
% Outputs
% wk1_B2I_B:    The spacecraft angular velocity at the k+1st time step
% qk1_B2I:      The quaternion describing the rotation from the body frame 
%               to the inertial frame at the k+1st time step
% biask1:       A 3x1 vector of biases at the k+1st time step
% Pk1:          The 6x6 diagonal covariance matrix at the k+1st time step
%
% References
% [1] Lefferts, E., Markley, F., and Shuster, M., "Kalman Filtering for
% Spacecraft Attitude Determination", Journal of Guidance, Control, and 
% Dynamics, Vol. 5, No. 5, pp. 417-429
% [2] Trawny, N. and Roumeliotis, S., "Indirect Kalman Filter for 3D
% Attitude Representation", Deparmtent of Computer Science and Engineering,
% University of Minnesota, 2005
%
% Written by: Matt Sorgenfrei                 matthew.c.sorgenfrei@nasa.gov
% Last Updated: 02/19/2013
%-------------------------------------------------------------------------%

% First assigne the elements of the vector sig for their respective uses
%sig_r = sig(1);         % Noise parameter for the quaternion elements
%sig_w = sig(2);         % Noise parameter for the angular velocity elements
%sig_ss = sig(3);        % Noise parameter for the sun sensor measurements
%sig_mag = sig(4);       % Noise parameter for the magnetometer measurements

% Declare persistent variables for the quaternion, the bias vector, the
% angular velocity, and the covariance (all at the kth time step) in order
% to enable the recursion
%persistent qk_I2B biask wk_B2I_B Pk


% Initialize the variables by checking to see if there is a value in the
% variable qk. If not, then assign the initial conditions to the variables

%if isempty(qk_I2B)
   % qk_I2B = q0_I2B;    % At t=0 the quaternion is just set to the initial value
%   biask = zeros(3,1); % Assume zero bias initially
   % wk_B2I_B = w_B2I_B;       % Assign the current angular velocity to wk
    
    %sig_n = sqrt(sig_ss^2+sig_mag^2);
    
    % The initial covariance matrix (which is 6x6 diagonal)uses values
    % hard-coded by Vince (0.87 rad)^2 and (9.7e-7 rad)^2
   % Pk=[(50*pi/180)^2*eye(3) zeros(3);... 
  %      zeros(3) (0.2/3600*pi/180)^2*eye(3)];
    
    % All of the values at the kth time step are assigned to the k+1st time
    % step
    %wk1_B2I_B = wk_B2I_B;
    %qk1_I2B = qk_I2B;
    %biask1 = biask;
    %Pk1 = Pk;
    %return;
%end

% Calculate the transpose of w for the non-simulink execution
%w_B2I_B = w_B2I_B';


% Initialize the indices used to move between sun sensor and magnetometer
% measurements
MaxSS = 1;          % Index of last sun sensor
MaxMag = 2;         % Index of last magnetometer

%----------Predict the system state at the k+1st time step----------------%
% Without additional info, we assume that the bias at the k+1st step simply
% equals that at the kth step
biask1 = biask;

% The skew-symmetric representation of w and its magnitude will be needed
Skew_w = Skew(wk_B2I_B);
%Mag_w  = norm(wk_B2I_B);

% The quaternion at the k+1st time step can be predicted using the one-step-ahead
% filter presented in [2]. To do so, first create the quaternion angular velocity
% matrix Omega   
Omega = [0 wk_B2I_B(3,1) -wk_B2I_B(2,1) wk_B2I_B(1,1);...
        -wk_B2I_B(3,1) 0 wk_B2I_B(1,1) wk_B2I_B(2,1);...
        wk_B2I_B(2,1) -wk_B2I_B(1,1) 0 wk_B2I_B(3,1);...
        -wk_B2I_B(1,1) -wk_B2I_B(2,1) -wk_B2I_B(3,1) 0;];
    
% Now calculate the predicted value of qk1_I2B
%qk1_I2B = (cos(Mag_w/2*dt)*eye(4) + (1/Mag_w)*sin(Mag_w/2*dt)*Omega)*qk_I2B; 

% Second formulation of qk1_I2B using a small angle approximation, which removes
% Mag_w from the denominator (necessary for when w_B2I_B --> 0
qk1_I2B = (eye(4) + (dt/2).*Omega)*qk_I2B;

% Since this Kalman filter uses the reduced 6 element state vector, we will
% create a state transition matrix Phi following the approach of [1] (Eqn
% 105). Note that this is a 6x6 vector, which will be defined in 3x3 blocks. The
% exact formulation of each block comes from Section 2.5.2 of [2]
%Phi_11 = eye(3)- Skew_w*sin(Mag_w*dt)/Mag_w + Skew_w^2*(1-cos(Mag_w*dt))/Mag_w^2;  

%Phi_12 = Skew_w*(1-cos(Mag_w*dt))/Mag_w^2 - eye(3)*dt -...                              
        % Skew_w^2*(Mag_w*dt-sin(Mag_w*dt))/Mag_w^3;
		
% Use the small-angle equivalents of Phi_11 and Phi_12 in order to avoid dividing by
% zero, as was done with the quaternion propagator
Phi_11 = eye(3) - dt*Skew_w + (dt^2/2)*(Skew_w^2);

Phi_12 = -eye(3)*dt + (dt^2/2)*Skew_w - (dt^3/6)*(Skew_w^2);
     
Phi_21 = zeros(3); 

Phi_22 = eye(3);                                                                       

% Create the full Phi matrix
Phi = [Phi_11 Phi_12; Phi_21 Phi_22];                                                   

% Define the input distribution matrix for the process noise as per [2]
Gk = [-eye(3) zeros(3); zeros(3) eye(3)];

% Create the covariance matrix for the process noise using [2]
%Qk = [ (sig_q^2*dt+1/3*sig_w^2*dt^3)*eye(3) -(1/2*sig_w^2*dt^2)*eye(3) ;
%      -(1/2*sig_w^2*dt^2)*eye(3)             (sig_w^2*dt)*eye(3)      ];

% Implement the small-angle approximation version of Q
% According to [2], the term sigma_r is the rate noise, while sigma_w is
% the random walk, e.g. w_meas = w + b + n_r, where b_dot = n_w
Qk_11 = sig_r^2*dt*eye(3) + sig_w^2*(eye(3)*(dt^3/3) + (2*dt^5/factorial(5))*(Skew_w^2));

Qk_12 = -sig_w^2*(eye(3)*(dt^2/2) - (dt^3/factorial(3))*Skew_w + (dt^4/factorial(4))*(Skew_w^2));

Qk_22 = sig_w^2*dt*eye(3);

Qk = [Qk_11 Qk_12; Qk_12' Qk_22;]; 

% Using Phi and the process noise predict the covariance one step ahead
Pk1 = Phi*Pk*Phi'+Gk*Qk*Gk';

%-----Now correct the state based upon the most recent measurement--------%

% First use the predicted quaternion to generate a predicted rotation
% matrix using the quat2rotmat function
Rk1_I2B = quat2rotmat(qk1_I2B);

% Create an empty 6x1 vector that represents the change in the state x
delX = zeros(6,1);

% Perform corrections based on the available measurements
for i = 1:MaxMag

%------------------Update for Sun Sensor Measurement----------------------%
        if( i == MaxSS && eclp==0  )   
             
            % The sun sensor can provide information about two axes of the
            % spacecraft?
            Att2ax=[Rk1_I2B(1:2,:); zeros(1,3)];
           
            % Create the observation matrix for the sun sensors only (a 3x6
            % matrix)
            H = [Skew(Rk1_I2B*SRef) zeros(3,3) ];
            
            % Construct the covariance matrix for the sun sensor
            % measuremetns
            %R = sig_ss^2*eye(3);

            % Calculate the Kalman gain for this portion of measurements
            K = (Pk1*H')/(H*Pk1*H' + R_ss);

            % Update the covariance using the gain and observations
            Pk1 = (eye(6) - K*H)*Pk1;
            
            % Calculate the measurement residual
            res = SMeas - Att2ax*SRef;
           
            % Update the state using the innovation from this measurement
            delX = delX + K*(res-H*delX);

%----------------Update for Magnetometer Measurement----------------------%
        elseif( i == MaxMag )   % to max number of Magnetometers
            
            % Create the observation matrix for the magnetometer
            % measurement (a 3x6 matrix)
            H = [Skew(Rk1_I2B*BRef) zeros(3,3)];
            
            % Create the covariance matrix for the magnetometer
            %R = sig_mag^2*eye(3);

            % Kalman gain for magnetometer measurements
            K = (Pk1*H')/(H*Pk1*H' + R_m);

            % Update the covariance using the magnetometer-derived data
            Pk1 = (eye(6) - K*H)*Pk1;
            
            % Calculate the measurement residual
            res = BMeas - Rk1_I2B*BRef;
            
            % Update the state using the innovation from this measurement
            delX = delX + K*(res-H*delX);

        end
end

% Using the updated information from the measurements, correct the previous
% prediction for the states

del_qk1_vec = 0.5*delX(1:3,:);

del_qk1_ns = del_qk1_vec'*del_qk1_vec;

if del_qk1_ns > 1
        del_qk1 = (1/(sqrt(1 + del_qk1_ns))).*[del_qk1_vec; 1;];
else
		del_qk1 = [del_qk1_vec; sqrt(1 - del_qk1_ns)];
end
	
qk1_I2B = quatprod(del_qk1,qk1_I2B);

% Update the estimate for the bias using the new information from the
% filter state vector
biask1 = biask1 + delX(4:6,:);

% Update the angular velocity prediction using the updated bias information
wk1_B2I_B = wk_B2I_B - biask1;

% Overwrite the persistent variable values using the corrected values 
%qk_I2B = qk1_I2B;
%biask = biask1;
%wk_B2I_B = wk1_B2I_B;
%Pk = Pk1;